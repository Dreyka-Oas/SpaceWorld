export default function createStarfield(count = 1500) {
  const stars = [];
  const rng = (a, b) => a + Math.random() * (b - a);
  const WIDTH = 4000;
  const HEIGHT = 4000;

  for (let i = 0; i < count; i++) {
    const depth = rng(0.1, 2.0);
    stars.push({
      x: rng(-WIDTH/2, WIDTH/2),
      y: rng(-HEIGHT/2, HEIGHT/2),
      size: Math.random() * 1.5 + 0.5,
      brightness: rng(0.3, 1.0),
      z: depth
    });
  }

  function update(dt, speed, vx, vy) {
    for (let s of stars) {
      const parallax = 0.02 * s.z; 

      s.x += vx * dt * parallax;
      s.y += vy * dt * parallax;

      if (s.x < -WIDTH/2) s.x += WIDTH;
      if (s.x > WIDTH/2) s.x -= WIDTH;
      if (s.y < -HEIGHT/2) s.y += HEIGHT;
      if (s.y > HEIGHT/2) s.y -= HEIGHT;
    }
  }

  function draw(ctx, w, h, cx, cy) {
    ctx.save();
    ctx.fillStyle = "#000000";
    ctx.fillRect(0, 0, w, h);

    const left = -w/2;
    const right = w/2;
    const top = -h/2;
    const bottom = h/2;

    ctx.translate(w/2, h/2);

    for (let s of stars) {
      const renderX = s.x;
      const renderY = s.y;

      if (renderX < left || renderX > right || renderY < top || renderY > bottom) continue;

      const size = s.size;
      const alpha = s.brightness;

      ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
      ctx.beginPath();
      ctx.arc(renderX, renderY, size, 0, Math.PI * 2);
      ctx.fill();
    }
    
    ctx.restore();
  }

  return { update, draw };
}