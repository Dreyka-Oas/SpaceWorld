import createMap from "./map.js";

export function createRenderer({ canvas, ctx, state }) {
  let raf = null;
  let last = performance.now();
  let frameCount = 0;
  let lastFpsTime = 0;

  const mapCanvas = document.getElementById("mapCanvas");
  const mapBtn = document.getElementById("mapBtn");
  const mapOverlay = document.getElementById("mapOverlay");
  const mapClose = document.getElementById("mapClose");
  const mapPanel = document.getElementById("mapPanel");
  const mapSearch = document.getElementById("mapSearch");
  
  const mapConfirm = document.getElementById("mapConfirm");
  const confName = document.getElementById("confName");
  const confTime = document.getElementById("confTime");
  const confWarn = document.getElementById("confWarn");
  const confStartBtn = document.getElementById("confStartBtn");

  const fpsVal = document.getElementById("fpsVal");
  const radarCanvas = document.getElementById("radarCanvas");
  const radarCtx = radarCanvas ? radarCanvas.getContext("2d") : null;
  
  const hudNavEl = document.getElementById("hud-nav");

  let mapInstance = null;
  let pendingTarget = null; 
  let isMapOpen = false;

  const VIEW_SCALE = 0.04; 

  function drawRealisticBody(ctx, cx, cy, radius, p) {
    ctx.save();
    if (p.hasRings) {
      ctx.save(); ctx.translate(cx, cy); ctx.rotate(Math.PI / 6);
      ctx.beginPath(); ctx.ellipse(0, 0, radius * 2.2, radius * 0.6, 0, 0, Math.PI*2);
      ctx.strokeStyle = p.ringColor || "rgba(200,200,200,0.3)"; ctx.lineWidth = radius * 0.4; ctx.stroke(); ctx.restore();
    }
    const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, radius);
    if (p.type === 'star') { grad.addColorStop(0, "#fff"); grad.addColorStop(0.2, "#ffaa00"); grad.addColorStop(1, "#ff5500"); }
    else if (p.name === "Jupiter") { grad.addColorStop(0, "#d9c19b"); grad.addColorStop(0.5, "#a88"); grad.addColorStop(1, "#d9c19b"); }
    else if (p.name === "Terre") { grad.addColorStop(0, "#2255ff"); grad.addColorStop(1, "#001144"); }
    else { grad.addColorStop(0, p.color); grad.addColorStop(1, "#000"); }
    ctx.fillStyle = grad; ctx.beginPath(); ctx.arc(cx, cy, radius, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  function drawBlackHole(ctx, cx, cy, radius, accretionSize) {
    ctx.save(); ctx.fillStyle="#000"; ctx.strokeStyle="#60a"; ctx.lineWidth=4;
    ctx.beginPath(); ctx.arc(cx, cy, radius, 0, Math.PI*2); ctx.fill(); ctx.stroke(); ctx.restore();
    ctx.strokeStyle="#fff"; ctx.lineWidth=1; ctx.beginPath(); ctx.arc(cx, cy, accretionSize, 0, Math.PI*2); ctx.stroke();
  }

  function drawRadar(ctx, w, h, time) {
    ctx.clearRect(0, 0, w, h);
    const cx = w/2; const cy = h/2;
    const maxR = w/2 - 10;
    const RADAR_RANGE = 200000; 

    ctx.strokeStyle = "rgba(0, 255, 100, 0.2)"; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(cx, cy, maxR, 0, Math.PI*2); ctx.stroke();
    ctx.beginPath(); ctx.arc(cx, cy, maxR*0.5, 0, Math.PI*2); ctx.stroke();

    const scanAngle = (time * 2.5) % (Math.PI * 2);
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(scanAngle);
    const scanGrad = ctx.createLinearGradient(0, 0, maxR, 0);
    scanGrad.addColorStop(0, "rgba(0, 255, 100, 0)"); scanGrad.addColorStop(1, "rgba(0, 255, 100, 0.2)");
    ctx.fillStyle = scanGrad; ctx.beginPath(); ctx.moveTo(0,0); ctx.arc(0, 0, maxR, -0.2, 0.2); ctx.fill();
    ctx.restore();

    const plot = (x, y, color, size) => {
      const dx = x - state.shipPosition.x;
      const dy = y - state.shipPosition.y;
      const dist = Math.hypot(dx, dy);
      if(dist < RADAR_RANGE) {
        const r = (dist / RADAR_RANGE) * maxR;
        const a = Math.atan2(dy, dx); 
        ctx.fillStyle = color;
        ctx.beginPath(); ctx.arc(cx + Math.cos(a)*r, cy + Math.sin(a)*r, size, 0, Math.PI*2); ctx.fill();
      }
    };

    if (state.spatialGrid) {
       const nearby = state.spatialGrid.getNearby(state.shipPosition.x, state.shipPosition.y);
       nearby.forEach(a => plot(a.x, a.y, "#f55", 2));
    }
    
    if(state.blackHoles) state.blackHoles.forEach(b => plot(b.x, b.y, "#a0f", 4));
    if(state.planets) state.planets.forEach(p => plot(p.x, p.y, "#0cf", 3));
    
    const shipHeading = Math.atan2(state.currentHeading.y, state.currentHeading.x) + Math.PI/2;
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(shipHeading);
    ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.moveTo(0, -6); ctx.lineTo(4, 5); ctx.lineTo(-4, 5); ctx.fill();
    ctx.restore();
  }

  if (mapCanvas) {
    mapInstance = createMap(mapCanvas, () => state.shipPosition, state.planets, state.asteroids, state.blackHoles);
    
    mapCanvas.addEventListener("map:select", (e) => {
      const d = e.detail;
      let target = null;
      let type = 'coords';
      let isRisky = false;
      let riskMsg = "";
      
      if (d.obj) {
        target = d.obj;
        type = 'obj';
        confName.textContent = "DEST : " + (d.obj.name || "OBJET").toUpperCase();
        
        if (target.type === 'blackhole') { isRisky = true; riskMsg = "⚠ GRAVITÉ EXTRÊME"; }
        else if (target.type === 'star') { isRisky = true; riskMsg = "⚠ CHALEUR CRITIQUE"; }
        else if (target.type === 'asteroid') { isRisky = true; riskMsg = "⚠ CIBLE INSTABLE"; }
        else {
           const giants = ["Jupiter", "Saturne", "Uranus", "Neptune"];
           if (giants.includes(target.name)) { isRisky = true; riskMsg = "⚠ NON RECOMMANDÉ (GAZEUSE)"; }
        }

      } else if (d.coords) {
        target = d.coords;
        confName.textContent = `COORDS : ${Math.round(d.coords.x)}`;
      }
      
      if(isRisky) { confWarn.style.display="block"; confWarn.textContent = riskMsg; } 
      else confWarn.style.display="none";

      if(target) {
         pendingTarget = { type, val: target };
         mapConfirm.style.display = "flex";
         updateMapETA();
      }
    });

    if (mapSearch) {
      mapSearch.addEventListener("input", (e) => {
        const val = e.target.value.toLowerCase();
        if (val.length < 2) return;
        const found = state.planets.find(p => p.name.toLowerCase().startsWith(val));
        if (found) { mapInstance.panToPlanet(found); }
      });
    }
  }

  confStartBtn && confStartBtn.addEventListener("click", () => {
    if (pendingTarget) {
      if (pendingTarget.type === 'obj') {
        state.navigateTo(pendingTarget.val.x, pendingTarget.val.y, pendingTarget.val.name, pendingTarget.val);
      } else {
        state.navigateTo(pendingTarget.val.x, pendingTarget.val.y);
      }
      closeMap();
    }
  });

  function openMap() { if(mapOverlay) { mapOverlay.style.display = "flex"; isMapOpen = true; if(mapInstance) { mapInstance.start(); mapInstance.centerOnShip(); mapInstance.resetSelection(); } } if(mapConfirm) mapConfirm.style.display="none"; pendingTarget=null; }
  function closeMap() { if(mapOverlay) { mapOverlay.style.display = "none"; isMapOpen = false; if(mapInstance) mapInstance.stop(); } }
  
  mapBtn && mapBtn.addEventListener("click", openMap);
  mapClose && mapClose.addEventListener("click", closeMap);
  mapPanel && mapPanel.addEventListener("click", (e) => e.stopPropagation());
  mapOverlay && mapOverlay.addEventListener("click", (e) => { if (e.target === mapOverlay) closeMap(); });

  function updateMapETA() {
    if (pendingTarget && mapConfirm.style.display !== 'none') {
       let tx, ty;
       if (pendingTarget.type === 'obj') { tx = pendingTarget.val.x; ty = pendingTarget.val.y; }
       else { tx = pendingTarget.val.x; ty = pendingTarget.val.y; }
       
       const distCenter = Math.hypot(tx - state.shipPosition.x, ty - state.shipPosition.y);
       
       // CORRECTION : On retire le rayon orbital estimé (1.5x le rayon de la planète)
       let displayDist = distCenter;
       if (pendingTarget.type === 'obj' && pendingTarget.val.size) {
           displayDist = Math.max(0, distCenter - (pendingTarget.val.size * 1.5));
       }

       const timeSec = displayDist / state.maxSpeed;
       const mins = Math.floor(timeSec / 60);
       const secs = Math.floor(timeSec % 60);
       confTime.textContent = `Temps estimé : ${mins}m ${secs}s`;
    }
  }

  function frame(now) {
    const dt = Math.min(0.05, (now - last) / 1000);
    const time = now / 1000;
    
    frameCount++;
    if (now - lastFpsTime >= 1000) {
      fpsVal.textContent = frameCount;
      frameCount = 0;
      lastFpsTime = now;
    }

    last = now;

    const info = state.updateLogic(dt);
    if (!state.isGameOver) {
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      
      state.starfield.draw(ctx, w, h, info.cx, info.cy);

      if(radarCtx) drawRadar(radarCtx, 220, 220, time);

      if (info.blackHoles) {
        for(let bh of info.blackHoles) {
           const sx = info.cx + (bh.x - info.shipX) * VIEW_SCALE;
           const sy = info.cy + (bh.y - info.shipY) * VIEW_SCALE;
           if (sx < -2000 || sx > w+2000 || sy < -2000 || sy > h+2000) continue;
           drawBlackHole(ctx, sx, sy, bh.size * VIEW_SCALE, bh.accretionSize * VIEW_SCALE);
        }
      }

      if (info.spatialGrid) {
         const visibleAsteroids = info.spatialGrid.getNearby(info.shipX, info.shipY);
         
         ctx.fillStyle = "#666";
         for(let a of visibleAsteroids) {
           const sx = info.cx + (a.x - info.shipX) * VIEW_SCALE;
           const sy = info.cy + (a.y - info.shipY) * VIEW_SCALE;
           
           if (sx < -100 || sx > w+100 || sy < -100 || sy > h+100) continue;
           
           ctx.save(); ctx.translate(sx, sy); ctx.rotate(a.rotation);
           ctx.beginPath();
           if(a.points && a.points.length > 0) {
             ctx.moveTo(a.points[0].x * VIEW_SCALE, a.points[0].y * VIEW_SCALE);
             for(let k=1; k<a.points.length; k++) ctx.lineTo(a.points[k].x * VIEW_SCALE, a.points[k].y * VIEW_SCALE);
           } else {
             const s = a.size * VIEW_SCALE; ctx.rect(-s/2, -s/2, s, s);
           }
           ctx.closePath(); ctx.fillStyle = a.color || "#555"; ctx.fill(); ctx.restore();
         }
      }

      if (state.particles) {
        for(let p of state.particles) {
           const sx = info.cx + (p.x - info.shipX) * VIEW_SCALE;
           const sy = info.cy + (p.y - info.shipY) * VIEW_SCALE;
           if (sx < 0 || sx > w || sy < 0 || sy > h) continue;

           ctx.fillStyle = p.color; ctx.globalAlpha = p.life;
           ctx.beginPath(); ctx.arc(sx, sy, p.size * VIEW_SCALE, 0, Math.PI*2); ctx.fill();
           ctx.globalAlpha = 1.0;
        }
      }

      if (Array.isArray(info.planets)) {
        for (let p of info.planets) {
          const sx = info.cx + (p.x - info.shipX) * VIEW_SCALE;
          const sy = info.cy + (p.y - info.shipY) * VIEW_SCALE;
          
          const distToCenter = Math.hypot(sx - w/2, sy - h/2);
          const drawRadius = p.size * VIEW_SCALE;
          
          if (distToCenter > (Math.max(w,h)/2 + drawRadius + 500)) continue;

          if (p.moons) {
            for(let m of p.moons) {
              const msX = info.cx + (m.x - info.shipX) * VIEW_SCALE;
              const msY = info.cy + (m.y - info.shipY) * VIEW_SCALE;
              ctx.fillStyle = m.color || "#ccc";
              ctx.beginPath(); ctx.arc(msX, msY, m.size * VIEW_SCALE, 0, Math.PI*2); ctx.fill();
            }
          }
          drawRealisticBody(ctx, sx, sy, drawRadius, p);
          
          ctx.fillStyle = "rgba(255,255,255,0.8)";
          ctx.font = "12px 'Segoe UI', sans-serif";
          ctx.textAlign = "center";
          ctx.fillText(p.name, sx, sy - drawRadius - 15);
        }
      }

      if (info.navigationActive) {
        const nav = state.navigation;
        const screenX = info.cx + (nav.targetX - info.shipX) * VIEW_SCALE;
        const screenY = info.cy + (nav.targetY - info.shipY) * VIEW_SCALE;
        const onScreen = screenX >= -2000 && screenX <= w + 2000 && screenY >= -2000 && screenY <= h + 2000;
        if (onScreen) {
          ctx.save(); ctx.strokeStyle = "#4aff4a"; ctx.lineWidth = 2; ctx.setLineDash([4, 4]);
          ctx.beginPath(); ctx.arc(screenX, screenY, 40, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
        }
      }

      state.ship.draw(ctx, info.cx, info.cy, 1.0, info.angle, info.t, info.thrustParams.thrust, info.thrustParams.speedRatio);
    }
    
    if (info.orbitActive && info.orbitTimer > 3.0) {
        if(hudNavEl) hudNavEl.classList.add('hud-hidden');
    } else if (info.navigationActive) {
        if(hudNavEl) {
            hudNavEl.style.display = 'flex';
            hudNavEl.classList.remove('hud-hidden');
        }
    }

    if (isMapOpen) updateMapETA();
    
    raf = requestAnimationFrame(frame);
  }

  return {
    start() { if (!raf) { last = performance.now(); raf = requestAnimationFrame(frame); } },
    stop() { if (raf) { cancelAnimationFrame(raf); raf = null; } mapInstance && mapInstance.stop(); }
  };
}