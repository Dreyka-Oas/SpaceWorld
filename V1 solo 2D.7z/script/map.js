export default function createMap(canvas, getShipPos, planets = [], asteroids = [], blackHoles = []) {
  const ctx = canvas.getContext("2d");
  let raf = null;
  let startTime = 0;

  let offsetX = 0;
  let offsetY = 0;
  let scale = 0.8; 
  let isPanning = false;
  let lastPointer = null;
  
  let selectedObj = null; 
  let selectedCoords = null;

  // ECHELLE ENCORE PLUS PETITE (Univers x5)
  const MAP_SCALE = 0.00003; 

  function centerOnShip() {
    if(typeof getShipPos === "function") {
       const sp = getShipPos(); 
       offsetX = -(sp.x * MAP_SCALE) * scale;
       offsetY = -(sp.y * MAP_SCALE) * scale;
    }
  }

  function drawRealisticBody(ctx, cx, cy, radius, p) {
    ctx.save();
    if (p.hasRings) {
      ctx.save(); ctx.translate(cx, cy); ctx.rotate(Math.PI / 6);
      ctx.beginPath(); ctx.ellipse(0, 0, radius * 2.2, radius * 0.6, 0, 0, Math.PI*2);
      ctx.strokeStyle = p.ringColor || "rgba(200,200,200,0.3)"; ctx.lineWidth = radius * 0.4; ctx.stroke(); ctx.restore();
    }
    const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, radius);
    if (p.type === 'star') { grad.addColorStop(0, "#fff"); grad.addColorStop(0.2, "#ffaa00"); grad.addColorStop(1, "#ff5500"); }
    else if (p.name === "Jupiter") { grad.addColorStop(0, "#d9c19b"); grad.addColorStop(0.5, "#a88"); grad.addColorStop(1, "#d9c19b"); }
    else if (p.name === "Terre") { grad.addColorStop(0, "#2255ff"); grad.addColorStop(1, "#001144"); }
    else { grad.addColorStop(0, p.color); grad.addColorStop(1, "#000"); }
    ctx.fillStyle = grad; ctx.beginPath(); ctx.arc(cx, cy, radius, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  function draw(now) {
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = "#050505"; ctx.fillRect(0, 0, w, h);

    const cx = w / 2 + offsetX;
    const cy = h / 2 + offsetY;

    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(scale, scale);

    // Orbites
    for (let p of planets) {
      if (p.orbitalRadius > 0) {
        ctx.strokeStyle = (selectedObj === p) ? "rgba(74, 255, 74, 0.4)" : "rgba(255,255,255,0.08)";
        ctx.lineWidth = 1/scale;
        ctx.beginPath(); ctx.arc(0, 0, p.orbitalRadius * MAP_SCALE, 0, Math.PI * 2); ctx.stroke();
      }
    }

    // Astéroïdes
    if (asteroids) {
       ctx.fillStyle = "#666";
       for(let a of asteroids) {
         if (scale < 0.2 && Math.random() > 0.1) continue; 
         const ax = a.x * MAP_SCALE;
         const ay = a.y * MAP_SCALE;
         const aSize = Math.max(0.5/scale, a.size * MAP_SCALE);
         ctx.beginPath(); ctx.arc(ax, ay, aSize, 0, Math.PI*2); ctx.fill();
         if(selectedObj === a) { ctx.strokeStyle = "#4aff4a"; ctx.lineWidth = 1/scale; ctx.stroke(); }
       }
    }

    // Trous Noirs
    if (blackHoles) {
      for(let bh of blackHoles) {
        const bx = bh.x * MAP_SCALE;
        const by = bh.y * MAP_SCALE;
        const bSize = Math.max(4/scale, bh.size * MAP_SCALE * 2);
        ctx.fillStyle = "#000"; ctx.strokeStyle = "#a0f"; ctx.lineWidth = 2/scale;
        ctx.beginPath(); ctx.arc(bx, by, bSize, 0, Math.PI*2); ctx.fill(); ctx.stroke();
        if (selectedObj === bh) { ctx.strokeStyle = "#4aff4a"; ctx.lineWidth = 2/scale; ctx.stroke(); }
      }
    }

    // Planètes
    for (let p of planets) {
      const px = p.x * MAP_SCALE;
      const py = p.y * MAP_SCALE;
      const size = Math.max(4/scale, p.size * MAP_SCALE * 3);

      if (p.moons && scale > 0.5) {
        for(let m of p.moons) {
          const mPosX = m.x * MAP_SCALE;
          const mPosY = m.y * MAP_SCALE;
          const mSize = Math.max(1/scale, m.size * MAP_SCALE * 3);
          ctx.fillStyle = "#aaa"; ctx.beginPath(); ctx.arc(mPosX, mPosY, mSize, 0, Math.PI*2); ctx.fill();
        }
      }

      if (selectedObj === p) {
        const pulse = 1 + Math.sin(now * 0.008) * 0.3;
        ctx.strokeStyle = "#4aff4a"; ctx.lineWidth = 2 / scale;
        ctx.beginPath(); ctx.arc(px, py, size * 1.8 * pulse, 0, Math.PI * 2); ctx.stroke();
      }

      drawRealisticBody(ctx, px, py, size, p);

      if (scale > 0.2) {
        ctx.fillStyle = (selectedObj === p) ? "#4aff4a" : "rgba(200,220,255,0.7)";
        ctx.font = `${12/scale}px "Segoe UI", sans-serif`;
        ctx.textAlign = "center";
        ctx.fillText(p.name, px, py - size - 4/scale);
      }
    }

    if (selectedCoords) {
      const tx = selectedCoords.x * MAP_SCALE;
      const ty = selectedCoords.y * MAP_SCALE;
      ctx.strokeStyle = "#4aff4a"; ctx.lineWidth = 2 / scale;
      ctx.beginPath(); ctx.arc(tx, ty, 8/scale, 0, Math.PI*2); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(tx-4/scale, ty); ctx.lineTo(tx+4/scale, ty); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(tx, ty-4/scale); ctx.lineTo(tx, ty+4/scale); ctx.stroke();
    }

    if (typeof getShipPos === "function") {
      const sp = getShipPos(); 
      const sx = sp.x * MAP_SCALE;
      const sy = sp.y * MAP_SCALE;
      const pulseShip = 1 + Math.sin(now * 0.005) * 0.4;
      ctx.strokeStyle = "rgba(74, 255, 74, 0.4)"; ctx.lineWidth = 1 / scale;
      ctx.beginPath(); ctx.arc(sx, sy, (20 / scale) * pulseShip, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(sx, sy, 3 / scale, 0, Math.PI * 2); ctx.fill();

      let tx, ty;
      if (selectedObj) { tx = selectedObj.x * MAP_SCALE; ty = selectedObj.y * MAP_SCALE; }
      else if (selectedCoords) { tx = selectedCoords.x * MAP_SCALE; ty = selectedCoords.y * MAP_SCALE; }

      if (tx !== undefined) {
        ctx.strokeStyle = "rgba(74, 255, 74, 0.5)"; ctx.lineWidth = 1 / scale;
        ctx.setLineDash([10/scale, 10/scale]);
        ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(tx, ty); ctx.stroke();
        ctx.setLineDash([]);
      }
    }

    ctx.restore();
  }

  function loop(now) { draw(now || performance.now()); raf = requestAnimationFrame(loop); }

  function getObjectAtPosition(worldX, worldY) {
    for(let b of blackHoles) if(Math.hypot(worldX - b.x, worldY - b.y) < Math.max(b.size * 4, 3000/scale)) return b;
    for(let p of planets) if(Math.hypot(worldX - p.x, worldY - p.y) < Math.max(p.size * 4, 3000/scale)) return p;
    for(let a of asteroids) if(Math.hypot(worldX - a.x, worldY - a.y) < Math.max(a.size * 4, 2000/scale)) return a;
    return null;
  }

  function getWorldPosFromScreen(sx, sy) {
    const w = canvas.clientWidth; const h = canvas.clientHeight;
    const cx = w/2 + offsetX; const cy = h/2 + offsetY;
    const wx = ((sx - cx) / scale) / MAP_SCALE;
    const wy = ((sy - cy) / scale) / MAP_SCALE;
    return { x: wx, y: wy };
  }

  function onPointerDown(e) { isPanning = true; lastPointer = { x: e.clientX, y: e.clientY }; canvas.setPointerCapture && canvas.setPointerCapture(e.pointerId); }
  function onPointerMove(e) {
    if (isPanning && lastPointer) {
      const dx = e.clientX - lastPointer.x;
      const dy = e.clientY - lastPointer.y;
      offsetX += dx; offsetY += dy;
      lastPointer = { x: e.clientX, y: e.clientY };
    }
  }
  function onPointerUp(e) {
    if (!isPanning) return;
    isPanning = false;
    const rect = canvas.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;
    const worldPos = getWorldPosFromScreen(clickX, clickY);
    const hit = getObjectAtPosition(worldPos.x, worldPos.y);
    if (hit) {
      selectedObj = hit; selectedCoords = null;
      canvas.dispatchEvent(new CustomEvent("map:select", { detail: { obj: hit } }));
    } else {
      selectedObj = null; selectedCoords = worldPos;
      canvas.dispatchEvent(new CustomEvent("map:select", { detail: { coords: worldPos } }));
    }
  }
  function onWheel(e) {
    e.preventDefault();
    const zoom = Math.exp(-e.deltaY * 0.0015);
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const w = canvas.width / (window.devicePixelRatio || 1); 
    const h = canvas.height / (window.devicePixelRatio || 1);
    const cx = w/2; const cy = h/2;
    const worldX = (mouseX - cx - offsetX) / scale;
    const worldY = (mouseY - cy - offsetY) / scale;
    const prevScale = scale;
    scale = Math.max(0.01, Math.min(200, scale * zoom));
    offsetX -= worldX * (scale - prevScale);
    offsetY -= worldY * (scale - prevScale);
  }
  function attach() {
    canvas.addEventListener("pointerdown", onPointerDown);
    window.addEventListener("pointermove", onPointerMove);
    window.addEventListener("pointerup", onPointerUp);
    canvas.addEventListener("wheel", onWheel, { passive: false });
  }
  function detach() {
    canvas.removeEventListener("pointerdown", onPointerDown);
    window.removeEventListener("pointermove", onPointerMove);
    window.removeEventListener("pointerup", onPointerUp);
    canvas.removeEventListener("wheel", onWheel);
  }

  return {
    start() { if (!startTime) startTime = performance.now(); if (!raf) raf = requestAnimationFrame(loop); attach(); },
    stop() { if (raf) { cancelAnimationFrame(raf); raf = null; } detach(); },
    resetSelection() { selectedObj = null; selectedCoords = null; },
    panToPlanet(p) {
      selectedObj = p;
      offsetX = -(p.x * MAP_SCALE * scale);
      offsetY = -(p.y * MAP_SCALE * scale);
      canvas.dispatchEvent(new CustomEvent("map:select", { detail: { obj: p } }));
    },
    centerOnShip
  };
}