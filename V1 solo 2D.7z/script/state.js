import createStarfield from "./starfield.js";
import createShip from "./ship.js";
import { generateObstacles } from "./obstacles.js";
import { applyGravity, checkCollisions, getNavigationVector, SpatialGrid } from "./physics.js";
import { findSafeSpawnPosition } from "./spawner.js"; // NOUVEL IMPORT

function lerpAngle(a, b, t) {
  const da = (b - a) % (2 * Math.PI);
  const delta = (2 * da) % (2 * Math.PI) - da;
  return a + delta * t;
}

// Gestionnaire de Trous Noirs
class BlackHoleManager {
  constructor() {
    this.holes = [];
    this.maxHoles = 8;
    this.spawnTimer = 0;
  }

  update(dt, shipX, shipY, mapLimit) {
    // 1. Update existants
    for (let i = this.holes.length - 1; i >= 0; i--) {
      const bh = this.holes[i];
      if (bh.state === 'growing') {
        bh.size += dt * 200; 
        if (bh.size >= bh.targetSize) {
          bh.size = bh.targetSize;
          bh.state = 'stable';
          bh.lifeTime = 180 + Math.random() * 1020; 
        }
      } else if (bh.state === 'stable') {
        bh.lifeTime -= dt;
        if (bh.lifeTime <= 0) bh.state = 'shrinking';
      } else if (bh.state === 'shrinking') {
        bh.size -= dt * 300;
        if (bh.size <= 10) {
          this.holes.splice(i, 1); 
          continue;
        }
      }
      
      bh.gravityRadius = bh.size * 20; 
      bh.accretionSize = bh.size * 2.5;
    }

    // 2. Spawning
    if (this.holes.length < this.maxHoles) {
      if (Math.random() < 0.001) { 
        const angle = Math.random() * Math.PI * 2;
        const dist = 500000 + Math.random() * (mapLimit - 500000);
        
        const bx = Math.cos(angle) * dist;
        const by = Math.sin(angle) * dist;
        if (Math.hypot(bx - shipX, by - shipY) > 200000) {
            const targetSize = 50000 + Math.random() * 600000;
            this.holes.push({
              x: bx, y: by,
              size: 100, 
              targetSize: targetSize,
              state: 'growing',
              type: 'blackhole',
              name: 'ANOMALIE ' + Math.floor(Math.random()*1000),
              gravity: true,
              gravityRadius: 1000,
              hitboxScale: 0.6
            });
        }
      }
    }
  }
}

class ParticleSystem {
  constructor(maxParticles) {
    this.pool = [];
    for(let i=0; i<maxParticles; i++) {
      this.pool.push({ x:0, y:0, vx:0, vy:0, life:0, size:0, color:'#fff', active: false });
    }
  }

  spawn(x, y, size, color) {
    const count = Math.min(50, 10 + Math.floor(size / 50)); 
    for(let i=0; i<count; i++) {
      let p = this.pool.find(p => !p.active);
      if (!p) return; 

      const angle = Math.random() * Math.PI * 2;
      const speed = 100 + Math.random() * 800;
      
      p.active = true;
      p.x = x; p.y = y;
      p.vx = Math.cos(angle) * speed;
      p.vy = Math.sin(angle) * speed;
      p.life = 0.5 + Math.random() * 1.5;
      p.size = Math.random() * size * 0.6;
      p.color = color;
    }
  }

  update(dt) {
    for(let i=0; i<this.pool.length; i++) {
      const p = this.pool[i];
      if (p.active) {
        p.life -= dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        if (p.life <= 0) p.active = false;
      }
    }
  }
}

export function createState({ canvas, container }) {
  const ctx = canvas.getContext("2d");

  // UI ELEMENTS
  const speedValEl = document.getElementById("speedVal");
  const coordsValEl = document.getElementById("coordsVal");
  const hudNavEl = document.getElementById("hud-nav");
  const navTargetNameEl = document.getElementById("navTargetName");
  const navDistValEl = document.getElementById("navDistVal");
  const navTimeValEl = document.getElementById("navTimeVal");
  const navProgressBar = document.getElementById("navProgressBar");
  const stabBadge = document.getElementById("stabBadge");
  const dangerAlert = document.getElementById("dangerAlert");
  const gameOverOverlay = document.getElementById("gameOverOverlay");
  const gameOverMsg = document.getElementById("gameOverMsg");

  let last = performance.now();

  const starfield = createStarfield(2000);
  const ship = createShip();
  const particleSystem = new ParticleSystem(1500);
  const blackHoleManager = new BlackHoleManager();

  let shipX = 0; 
  let shipY = 0;
  
  const planets = [
    { name: "Soleil", color: "#ffaa00", x: 0, y: 0, size: 800000, orbitalRadius: 0, type: "star", gravity: true, gravityRadius: 6000000, moons: [] },
    { name: "Mercure", color: "#9aa0a6", x: 0, y: 0, size: 25000, orbitalRadius: 5000000, type: "planet", moons: [] },
    { name: "Vénus", color: "#e3b27a", x: 0, y: 0, size: 55000, orbitalRadius: 9000000, type: "planet", moons: [] },
    { 
      name: "Terre", color: "#4aa1ff", x: 0, y: 0, size: 60000, orbitalRadius: 15000000, type: "planet", 
      moons: [{ name: "Lune", size: 16000, dist: 200000, color: "#ccc", angle: 0, speed: 0.5, type: "moon" }] 
    },
    { 
      name: "Mars", color: "#ff8a5a", x: 0, y: 0, size: 35000, orbitalRadius: 22000000, type: "planet",
      moons: [
        { name: "Phobos", size: 5000, dist: 70000, color: "#a88", angle: 0, speed: 1.0, type: "moon" },
        { name: "Deimos", size: 4000, dist: 100000, color: "#977", angle: 2, speed: 0.8, type: "moon" }
      ]
    },
    { 
      name: "Jupiter", color: "#d9c19b", x: 0, y: 0, size: 350000, orbitalRadius: 40000000, type: "planet", gravity: true, gravityRadius: 2000000,
      moons: [
        { name: "Io", size: 20000, dist: 500000, color: "#dd4", angle: 0, speed: 0.4, type: "moon" },
        { name: "Europe", size: 18000, dist: 600000, color: "#adf", angle: 1.5, speed: 0.35, type: "moon" },
        { name: "Ganymède", size: 30000, dist: 700000, color: "#987", angle: 3, speed: 0.3, type: "moon" },
        { name: "Callisto", size: 28000, dist: 850000, color: "#655", angle: 4.5, speed: 0.25, type: "moon" }
      ]
    },
    { 
      name: "Saturne", color: "#f1e1b8", x: 0, y: 0, size: 300000, orbitalRadius: 60000000, type: "planet", gravity: true, gravityRadius: 1800000,
      hasRings: true, ringColor: "rgba(200, 180, 150, 0.4)",
      moons: [{ name: "Titan", size: 28000, dist: 550000, color: "#eb4", angle: 1, speed: 0.3, type: "moon" }]
    },
    { 
      name: "Uranus", color: "#9fe3e8", x: 0, y: 0, size: 140000, orbitalRadius: 80000000, type: "planet", 
      hasRings: true, ringColor: "rgba(150, 220, 255, 0.3)",
      moons: [{ name: "Titania", size: 9000, dist: 300000, color: "#ccc", angle: 0, speed: 0.4, type: "moon" }] 
    },
    { 
      name: "Neptune", color: "#557ee6", x: 0, y: 0, size: 135000, orbitalRadius: 100000000, type: "planet", 
      moons: [{ name: "Triton", size: 15000, dist: 350000, color: "#fbd", angle: 0, speed: -0.3, type: "moon" }] 
    },
  ];

  const MAP_LIMIT = 110000000; 
  const obstData = generateObstacles(MAP_LIMIT);
  const asteroids = obstData.asteroids;
  
  const spatialGrid = new SpatialGrid(250000); 

  // --- INITIALISATION ---
  (function initWorld() {
    // 1. Placer les planètes (Positions aléatoires sur leur orbite fixe)
    for (let i = 0; i < planets.length; i++) {
      const p = planets[i];
      if (p.orbitalRadius === 0) continue;
      const angle = Math.random() * Math.PI * 2;
      p.x = Math.cos(angle) * p.orbitalRadius;
      p.y = Math.sin(angle) * p.orbitalRadius;
    }

    // 2. Trouver un spawn sécurisé pour le vaisseau
    const safePos = findSafeSpawnPosition(MAP_LIMIT, planets, asteroids, blackHoleManager.holes);
    shipX = safePos.x;
    shipY = safePos.y;
  })();

  let currentSpeed = 0;
  let targetSpeed = 0;
  const maxSpeed = 30000; 
  const accel = 1200;

  let pointerX = container.clientWidth / 2;
  let pointerY = container.clientHeight / 2;
  let pointerDown = false;

  let stabilized = false;
  let desiredHeading = { x: 0, y: -1 };
  let currentHeading = { x: 0, y: -1 };
  let currentAngle = -Math.PI/2;
  const turnSpeed = 2.5;

  let isGameOver = false;

  const navigation = {
    active: false,
    targetX: 0,
    targetY: 0,
    totalDistance: 0,
    targetName: null,
    targetObj: null,
    arrivalRadius: 6000,
    status: "idle"
  };

  const orbit = {
    active: false,
    centerX: 0,
    centerY: 0,
    radius: 3000,
    angle: 0,
    speed: 0.5,
    timer: 0
  };

  const state = {
    canvas, container, ctx, starfield, ship, planets, asteroids, 
    get blackHoles() { return blackHoleManager.holes; },
    get particles() { return particleSystem.pool.filter(p => p.active); }, 
    get shipPosition() { return { x: shipX, y: shipY }; },
    get currentSpeed() { return currentSpeed; },
    get targetSpeed() { return targetSpeed; },
    get currentHeading() { return currentHeading; },
    get navigation() { return navigation; },
    get orbit() { return orbit; },
    get isGameOver() { return isGameOver; },
    get spatialGrid() { return spatialGrid; },
    maxSpeed, accel,
    bgOffset: () => ({ x: shipX, y: shipY }),
    
    setStabilized: (v) => {
      stabilized = !!v;
      stabBadge && (stabBadge.style.display = stabilized ? "block" : "none");
    },

    updatePointerFromEvent(ev) {
      if (isGameOver) return;
      const r = canvas.getBoundingClientRect();
      const x = (ev.clientX ?? (ev.touches && ev.touches[0] && ev.touches[0].clientX)) - r.left;
      const y = (ev.clientY ?? (ev.touches && ev.touches[0] && ev.touches[0].clientY)) - r.top;
      
      if (!isNaN(x) && !isNaN(y)) {
        pointerX = x;
        pointerY = y;
        if (!stabilized && !navigation.active) {
          const cx = canvas.clientWidth / 2;
          const cy = canvas.clientHeight / 2;
          const dx = pointerX - cx;
          const dy = pointerY - cy;
          const dist = Math.hypot(dx, dy) || 1;
          desiredHeading.x = dx / dist;
          desiredHeading.y = dy / dist;
          const deadZone = 40;
          if (dist > deadZone) {
            targetSpeed = Math.min(1, (dist - deadZone) / 300) * maxSpeed;
          } else {
            targetSpeed = 0;
          }
        }
      }
    },

    attachInput() {
      window.addEventListener("keydown", keydownHandler);
      canvas.addEventListener("pointermove", pointerMoveHandler);
      canvas.addEventListener("pointerdown", pointerDownHandler);
      window.addEventListener("pointerup", pointerUpHandler);
    },
    
    detachInput() {
      window.removeEventListener("keydown", keydownHandler);
      canvas.removeEventListener("pointermove", pointerMoveHandler);
      canvas.removeEventListener("pointerdown", pointerDownHandler);
      window.removeEventListener("pointerup", pointerUpHandler);
    },

    updateLogic(dt) {
      if (dt > 0.1) dt = 0.1;

      // Update des Lunes uniquement (Planètes fixes)
      for(let p of planets) {
        if(p.moons) {
          for(let m of p.moons) {
            m.angle += m.speed * dt * 0.5;
            m.x = p.x + Math.cos(m.angle) * m.dist;
            m.y = p.y + Math.sin(m.angle) * m.dist;
          }
        }
      }

      if (isGameOver) return { 
        now: performance.now(), dt, shipX, shipY, 
        shipPosition: { x: shipX, y: shipY },
        cx: canvas.clientWidth/2, cy: canvas.clientHeight/2, 
        angle: 0, thrustParams: {thrust:0, speedRatio:0}, 
        starfield, ship, planets, currentSpeed, maxSpeed, 
        navigationActive:false, orbitActive:false, orbitTimer:0, 
        asteroids, blackHoles: blackHoleManager.holes, particles, spatialGrid
      };

      blackHoleManager.update(dt, shipX, shipY, MAP_LIMIT);
      particleSystem.update(dt);

      spatialGrid.clear();
      const lenA = asteroids.length;
      for(let i=0; i<lenA; i++) {
        const a = asteroids[i];
        a.rotation += a.rotSpeed * dt;
        a.x += a.vx * dt;
        a.y += a.vy * dt;
        spatialGrid.add(a);
      }

      const localAsteroids = spatialGrid.getNearby(shipX, shipY);
      
      for(let i=localAsteroids.length-1; i>=0; i--) {
        const a = localAsteroids[i];
        for(let p of planets) {
           if(Math.hypot(a.x - p.x, a.y - p.y) < p.size + a.size) {
             const idx = asteroids.indexOf(a);
             if(idx > -1) asteroids.splice(idx, 1);
             break;
           }
        }
      }

      const blackHoles = blackHoleManager.holes;
      const gravEntities = [planets[0], ...blackHoles, planets[5], planets[6]];
      const gravity = applyGravity(shipX, shipY, gravEntities, dt);
      
      let allCollidables = [...blackHoles, ...planets];
      for(let p of planets) if(p.moons) allCollidables = allCollidables.concat(p.moons);

      const collMsg = checkCollisions(shipX, shipY, spatialGrid, allCollidables);
      if (collMsg) {
        isGameOver = true;
        gameOverMsg.textContent = collMsg;
        gameOverOverlay.style.display = "flex";
        particleSystem.spawn(shipX, shipY, 3000, "#fff");
        currentSpeed = 0; targetSpeed = 0;
        return;
      }

      if (dangerAlert) {
        if (gravity.maxForceRatio > 0.4) {
           dangerAlert.style.display = "block";
           dangerAlert.textContent = "⚠ ALERTE GRAVITATIONNELLE ⚠";
        } else {
           dangerAlert.style.display = "none";
        }
      }

      let moveX = 0;
      let moveY = 0;

      if (navigation.active) {
        const dx = navigation.targetX - shipX;
        const dy = navigation.targetY - shipY;
        const distCenter = Math.hypot(dx, dy); 
        
        let dynamicArrival = navigation.arrivalRadius;
        if (navigation.targetObj) {
           dynamicArrival = navigation.targetObj.size * 1.5; 
           if(navigation.targetObj.type === 'asteroid') dynamicArrival = 2000;
        }

        if (distCenter < dynamicArrival) {
          navigation.active = false;
          navigation.status = "idle";
          if (navigation.targetObj && navigation.targetObj.type === 'planet') {
            orbit.active = true;
            orbit.timer = 0;
            orbit.centerX = navigation.targetObj.x;
            orbit.centerY = navigation.targetObj.y;
            orbit.radius = navigation.targetObj.size * 1.25;
            orbit.angle = Math.atan2(shipY - orbit.centerY, shipX - orbit.centerX);
            orbit.speed = 3000 / orbit.radius; 
          }
        } else {
          const navResult = getNavigationVector(
            shipX, shipY, 
            navigation.targetX, navigation.targetY, 
            spatialGrid, allCollidables,
            Math.cos(currentAngle), Math.sin(currentAngle), 
            gravity,
            navigation.targetObj 
          );
          
          desiredHeading.x = navResult.x;
          desiredHeading.y = navResult.y;

          let cruiseSpeed = maxSpeed;
          const brakingDist = 1200000; 
          if (distCenter < brakingDist) {
            const progress = distCenter / brakingDist;
            cruiseSpeed = maxSpeed * Math.pow(progress, 0.65); 
            cruiseSpeed = Math.max(2000, cruiseSpeed); 
          }

          if (navResult.threatDetected) cruiseSpeed *= 0.6;

          currentSpeed = cruiseSpeed;
          stabilized = true;
          
          moveX = desiredHeading.x * cruiseSpeed;
          moveY = desiredHeading.y * cruiseSpeed;
          
          if (hudNavEl) {
            hudNavEl.style.display = "flex";
            hudNavEl.classList.remove('hud-hidden');
            navTargetNameEl.textContent = (navigation.targetName || "COORDONNÉES").toUpperCase();
            
            let displayDistance = distCenter;
            if (navigation.targetObj && navigation.targetObj.size) {
               displayDistance = Math.max(0, distCenter - (navigation.targetObj.size * 1.5));
            }
            
            const totalDistCorr = Math.max(1, navigation.totalDistance - (navigation.targetObj ? navigation.targetObj.size*1.5 : 0));
            const pct = Math.max(0, Math.min(100, (1 - displayDistance / totalDistCorr) * 100));
            
            navProgressBar.style.width = pct.toFixed(1) + "%";
            navDistValEl.textContent = `${Math.round(displayDistance / 1000)}k km`;
            
            const timeSec = displayDistance / Math.max(1, cruiseSpeed);
            navTimeValEl.textContent = `${Math.floor(timeSec/60)}:${Math.floor(timeSec%60).toString().padStart(2,'0')}`;
          }
        }
      }
      
      if (orbit.active) {
        orbit.angle += orbit.speed * dt;
        orbit.timer += dt;
        shipX = orbit.centerX + Math.cos(orbit.angle) * orbit.radius;
        shipY = orbit.centerY + Math.sin(orbit.angle) * orbit.radius;
        currentAngle = orbit.angle + Math.PI/2; 
        currentHeading.x = Math.cos(currentAngle);
        currentHeading.y = Math.sin(currentAngle);
        stabilized = true;
        currentSpeed = maxSpeed * 0.1;
        
        if (hudNavEl) {
          hudNavEl.style.display = "flex";
          navTargetNameEl.textContent = "EN ORBITE";
          navProgressBar.style.width = "100%";
          navDistValEl.textContent = "STABLE";
          navTimeValEl.textContent = "";
        }
      }

      if (!navigation.active && !orbit.active) {
        if (hudNavEl) hudNavEl.style.display = "none";
        
        if (stabilized) {
           const lookAheadX = shipX + Math.cos(currentAngle) * 150000;
           const lookAheadY = shipY + Math.sin(currentAngle) * 150000;
           
           const navResult = getNavigationVector(
              shipX, shipY, 
              lookAheadX, lookAheadY, 
              spatialGrid, allCollidables,
              Math.cos(currentAngle), Math.sin(currentAngle), 
              gravity,
              null
           );
           desiredHeading.x = navResult.x;
           desiredHeading.y = navResult.y;
           moveX = desiredHeading.x * currentSpeed;
           moveY = desiredHeading.y * currentSpeed;
        } else {
           if (currentSpeed < targetSpeed) currentSpeed = Math.min(targetSpeed, currentSpeed + accel * dt);
           else if (currentSpeed > targetSpeed) currentSpeed = Math.max(targetSpeed, currentSpeed - accel * dt);
           moveX = currentHeading.x * currentSpeed;
           moveY = currentHeading.y * currentSpeed;
        }
      }

      if (!orbit.active) {
        const desiredAngle = Math.atan2(desiredHeading.x ? desiredHeading.y : currentHeading.y, desiredHeading.x ? desiredHeading.x : currentHeading.x);
        currentAngle = lerpAngle(currentAngle, desiredAngle, turnSpeed * dt);
        currentHeading.x = Math.cos(currentAngle);
        currentHeading.y = Math.sin(currentAngle);

        if (navigation.active || stabilized) {
           moveX = currentHeading.x * currentSpeed;
           moveY = currentHeading.y * currentSpeed;
        }
      }

      const driftX = gravity.accX * dt * 50; 
      const driftY = gravity.accY * dt * 50;

      shipX += moveX * dt + driftX;
      shipY += moveY * dt + driftY;

      if (speedValEl) {
        speedValEl.textContent = Math.round(currentSpeed) + " KM/H";
        speedValEl.style.color = stabilized ? "#ffd580" : "#e6f0ff";
      }
      if (coordsValEl) coordsValEl.textContent = `${Math.round(shipX / 1000)}k, ${Math.round(shipY / 1000)}k`;

      const bgSpeedScale = 0.3; 
      starfield.update(dt, currentSpeed, -currentHeading.x * currentSpeed * bgSpeedScale, -currentHeading.y * currentSpeed * bgSpeedScale);

      return {
        now: performance.now(), dt, shipX, shipY,
        shipPosition: { x: shipX, y: shipY },
        cx: canvas.clientWidth / 2, cy: canvas.clientHeight / 2,
        angle: currentAngle + Math.PI / 2,
        thrustParams: { thrust: Math.min(1.5, currentSpeed / (maxSpeed * 0.8)), speedRatio: currentSpeed / maxSpeed },
        starfield, ship, planets, asteroids, blackHoles: blackHoleManager.holes, currentSpeed, maxSpeed, particles: particleSystem.pool.filter(p=>p.active),
        navigationActive: navigation.active, orbitActive: orbit.active, orbitTimer: orbit.timer, isGameOver,
        navigation, spatialGrid 
      };
    },

    navigateTo(x, y, objName = null, obj = null) {
      if (isGameOver) return;
      navigation.active = true;
      navigation.targetX = x;
      navigation.targetY = y;
      navigation.targetName = objName;
      navigation.targetObj = obj;
      
      navigation.totalDistance = Math.hypot(x - shipX, y - shipY);
      navigation.status = "approaching";
      
      if (!obj) {
        const closest = findClosestPlanet(x, y);
        if (closest.distance < closest.planet.size * 5) {
           navigation.targetPlanet = closest.planet;
           navigation.targetObj = closest.planet;
           navigation.targetName = closest.planet.name;
        } else {
           navigation.targetPlanet = null;
        }
      } else if (obj.type === 'planet') {
        navigation.targetPlanet = obj;
      } else {
        navigation.targetPlanet = null;
      }

      orbit.active = false;
      stabilized = true;
      if (stabBadge) stabBadge.style.display = "block";
      
      if(hudNavEl) {
        hudNavEl.style.display = "flex";
        hudNavEl.classList.remove('hud-hidden');
      }
    },

    navigateToPlanet(planetName) {
      const planet = planets.find(p => p.name === planetName);
      if (planet) {
        this.navigateTo(planet.x, planet.y, planet.name, planet);
        return true;
      }
      return false;
    },

    cancelNavigation() {
      navigation.active = false;
      navigation.status = "idle";
      navigation.targetPlanet = null;
      navigation.targetObj = null;
      orbit.active = false;
      stabilized = false;
      if (stabBadge) stabBadge.style.display = "none";
      if (hudNavEl) hudNavEl.style.display = "none";
      targetSpeed = 0;
    },

    toggleStabilization() {
      if (isGameOver) return;
      if (!stabilized) {
        stabilized = true;
        lockedHeading.x = currentHeading.x;
        lockedHeading.y = currentHeading.y;
        targetSpeed = currentSpeed; 
        stabBadge && (stabBadge.style.display = "block");
      } else {
        stabilized = false;
        orbit.active = false;
        navigation.active = false;
        stabBadge && (stabBadge.style.display = "none");
        if (hudNavEl) hudNavEl.style.display = "none";
      }
    },
  };

  function findClosestPlanet(x, y) {
    let closestPlanet = null;
    let minDistance = Infinity;
    for (const planet of planets) {
      const d = Math.hypot(x - planet.x, y - planet.y);
      if (d < minDistance) { minDistance = d; closestPlanet = planet; }
    }
    return { planet: closestPlanet, distance: minDistance };
  }

  function keydownHandler(e) {
    if (e.key === "ArrowUp") targetSpeed = Math.min(maxSpeed, targetSpeed + 2500);
    if (e.key === "ArrowDown") targetSpeed = Math.max(0, targetSpeed - 2500);
    if (e.code === "Space") { e.preventDefault(); state.toggleStabilization(); }
    if (e.key === "Escape") state.cancelNavigation();
  }
  function pointerMoveHandler(ev) { state.updatePointerFromEvent(ev); }
  function pointerDownHandler(ev) { pointerDown = true; state.updatePointerFromEvent(ev); }
  function pointerUpHandler() { pointerDown = false; }

  state.attachInput();
  return state;
}