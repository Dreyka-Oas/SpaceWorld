export function generateObstacles(mapRadius) {
  const asteroids = [];
  const blackHoles = []; 

  // OPTIMISATION : On réduit le nombre pour tenir les 144 FPS
  // C'est toujours très dense grâce à la taille des objets
  const scatteredCount = 4000; // Au lieu de 15 000
  const beltCount = 8000;      // Au lieu de 25 000
  
  // 1. Astéroïdes dispersés
  for (let i = 0; i < scatteredCount; i++) {
    const angle = Math.random() * Math.PI * 2;
    // On étale bien sur toute la map
    const dist = 500000 + Math.random() * (mapRadius - 500000); 
    const size = 300 + Math.random() * 800; 

    // Polygone
    const points = [];
    const numPoints = 5 + Math.floor(Math.random() * 4);
    for (let j = 0; j < numPoints; j++) {
      const a = (j / numPoints) * Math.PI * 2;
      const r = size * (0.7 + Math.random() * 0.5);
      points.push({ x: Math.cos(a) * r, y: Math.sin(a) * r });
    }

    const isFast = Math.random() > 0.95; 
    const vSpeed = isFast ? 600 + Math.random() * 1200 : 50 + Math.random() * 150;
    const vAngle = Math.random() * Math.PI * 2;

    asteroids.push({
      x: Math.cos(angle) * dist,
      y: Math.sin(angle) * dist,
      vx: Math.cos(vAngle) * vSpeed,
      vy: Math.sin(vAngle) * vSpeed,
      size: size,
      points: points,
      rotation: Math.random() * Math.PI,
      rotSpeed: (Math.random() - 0.5) * (isFast ? 3.0 : 0.8),
      color: isFast ? "#bbb" : `hsl(0, 0%, ${20 + Math.random() * 15}%)`,
      type: 'asteroid',
      name: `AST-${i}`
    });
  }

  // 2. Ceinture Dense (Bordure de map)
  const beltStart = mapRadius * 0.9;
  const beltWidth = mapRadius * 0.1;

  for (let i = 0; i < beltCount; i++) {
    const angle = Math.random() * Math.PI * 2;
    const dist = beltStart + Math.random() * beltWidth;
    const size = 600 + Math.random() * 1400; 
    
    const points = [];
    const numPoints = 5 + Math.floor(Math.random() * 4);
    for (let j = 0; j < numPoints; j++) {
      const a = (j / numPoints) * Math.PI * 2;
      const r = size * (0.8 + Math.random() * 0.4);
      points.push({ x: Math.cos(a) * r, y: Math.sin(a) * r });
    }

    asteroids.push({
      x: Math.cos(angle) * dist,
      y: Math.sin(angle) * dist,
      vx: (Math.random() - 0.5) * 80,
      vy: (Math.random() - 0.5) * 80,
      size: size,
      points: points,
      rotation: Math.random() * Math.PI,
      rotSpeed: (Math.random() - 0.5) * 0.6,
      color: "#222",
      type: 'asteroid',
      name: `BELT-${i}`
    });
  }

  return { asteroids, blackHoles };
}